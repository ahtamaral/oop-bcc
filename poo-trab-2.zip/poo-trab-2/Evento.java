public class Evento { 


    private String description;
    private int id;
    private int[] listaDePessoas = new int[100];
    private int recurrence = 0;

    public Evento(String description, int id) {
        this.description = description;
        this.id = id;
    }

    public void show() {
        System.out.println("[" + this.id + "] " + this.description );
    }

    public String getDescription(){ return this.description; }
    public int getId(){ return this.id; }
    public void call() { this.recurrence += 1; }
}
