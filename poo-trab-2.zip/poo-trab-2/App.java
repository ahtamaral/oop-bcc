import java.util.Scanner;

public class App {

    public static void printMenu(String[] options){
        for (String option : options){
            System.out.println(option);
        }
        System.out.print("Escolha uma operação : ");
    }


    public static void main(String[] args) {
        System.out.println("POO 2023.2 - Trabalho 2 (Eventos)\n");

        int currentPerson = 0;
        int currentEvent = 0;
        String name;
        String description;
        int id;

        Pessoa[] persons = new Pessoa[100];
        Evento[] events = new Evento[100];

        String[] options = {"\n[-1] - Cadastrar pessoa",
                            "[-2] - Cadastrar evento",
                            "[-3] - Listar pessoas\n",
                            "0 - SAIR\n",
        };
        Scanner scanner = new Scanner(System.in);
        int option = -1;
        while (option != 0) {
            printMenu(options);
            option = Integer.parseInt(scanner.nextLine());

            System.out.println(option);

            switch (option) {
                case -1:
                    System.out.println("Cadastro de pessoa.");

                    System.out.print("Nome: ");
                    name = scanner.nextLine();
                    System.out.print("Identificador: ");
                    id = Integer.parseInt(scanner.nextLine());

                    Pessoa p = new Pessoa(name, id);
                    p.show();

                    persons[currentPerson] = p;
                    currentPerson += 1;

                    break;
                case -2:
                    System.out.println("Cadastro de evento.");

                    System.out.print("Descrição: ");
                    description = scanner.nextLine();
                    System.out.print("Identificador: ");
                    id = Integer.parseInt(scanner.nextLine());

                    Evento e = new Evento (description, id);
                    e.show();

                    events[currentEvent] = e;
                    currentEvent += 1;

                    break;
                case -3:
                    System.out.println("Lista de pessoas.");
                    break;
            }
        }


    }
}