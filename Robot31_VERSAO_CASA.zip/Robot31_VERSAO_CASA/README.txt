Para compilar o projeto:

javac -d classes src/*.java

Para rodar:

cd classes
java App
