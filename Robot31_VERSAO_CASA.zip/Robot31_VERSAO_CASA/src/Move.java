public enum Move {
    STOP, UP, DOWN, LEFT, RIGHT;
}